package com.vpn.task;

import androidx.appcompat.app.AppCompatActivity;


import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;



public class MainActivity extends AppCompatActivity {

    Button hitMe;
    ImageButton reset;

    TextView hitCounter;
    Counter count = new Counter(0, 100, 0, 1);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        hitMe = findViewById(R.id.hitMe);
        reset = (ImageButton) findViewById(R.id.reset);
        hitCounter = findViewById(R.id.hitCounter);
    // Counter activity
        hitMe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                hitCounter.setText(count.plus(Integer.parseInt(hitCounter.getText().toString())) + "");
            }
        });

        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                hitCounter.setText(count.reset() + "");
            }
        });
    }


}



